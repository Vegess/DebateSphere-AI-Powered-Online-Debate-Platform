React frontend placeholder
