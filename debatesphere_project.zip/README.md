Refer to the full documentation in README_Canmore.
