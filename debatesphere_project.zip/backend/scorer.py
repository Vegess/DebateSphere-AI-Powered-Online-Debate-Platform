# Argument scoring logic
