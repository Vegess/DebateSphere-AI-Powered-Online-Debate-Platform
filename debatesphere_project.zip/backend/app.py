# Flask/FastAPI app entry point
